export const COIN_SEARCH_LOG_TABLE = process.env.COIN_SEARCH_LOG_TABLE
export const COIN_GECKO_URL = process.env.COIN_GECKO_URL
export const X_CG_API_KEY = process.env.X_CG_API_KEY
export const EMAIL_SENDER_LAMBDA = process.env.EMAIL_SENDER_LAMBDA
export const REGION =  process.env.REGION