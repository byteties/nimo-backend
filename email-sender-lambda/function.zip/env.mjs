export const SENDER_EMAIL =  process.env.SENDER_EMAIL
export const DESTINATION_EMAIL =  process.env.DESTINATION_EMAIL
export const REGION =  process.env.REGION